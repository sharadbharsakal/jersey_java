package com.example.resources;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;


@Path("/users")
public class UserResource {
	
	@GET
	@Produces({MediaType.APPLICATION_JSON})
	public List<String> getUser(){
		
		List <String> users = new ArrayList<>();
		users.add("---This is simple jersey project---");
		return users;
	}
	
	@POST
	@Produces({MediaType.APPLICATION_JSON})
	public Response SaveUser() {
		
		return Response.ok().build();
	}
	
}
