package com.example.jersey;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;
import com.example.resources.*;

@Component
@ApplicationPath("/api")
public class appConfig extends ResourceConfig {
	
	public appConfig()
	{
//		register(UserResource.class);
		packages("com.example.resources");
	}

}
